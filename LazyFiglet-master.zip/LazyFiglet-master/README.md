#Bismillah
#Assalamu-Alaikum 

[+] LazyFiglet :
    LazyFiglet is a bash script created By Technical Mujeeb.
    with the help of this tool we can display all fonts
    of figlet in one click. one click means it ask your name
    when you enter your name then this script starts 
    Generating figlet fonts one by one.In this script total
    181+ figlet fonts are present.and this is very easy to use.

[+] Requirments :
    here another file install.sh is also available.so you can 
    simply run this install.sh to install all requirments
    packages which helps you to display figlet fonts.

 [+] About :
     Name = Mujeeb 
     Github = https://github.com/TechnicalMujeeb/LazyFiglet.git
     YouTube = www.youtube.com/TechnicalMujeeb
     if you want to make changes on my script and again upload
     on github by your username.then make sure to give credit us by the github link....ok

[+] installation:
    
    chmod +x *

    sh install.sh

    (This command install all requirements packages. )      
     DOne !

[+] usage :
    
    sh lfiglet
    [+] Enter you name : you text here

    (Then this script starts generating 181+ figlet fonts on you terminal )    